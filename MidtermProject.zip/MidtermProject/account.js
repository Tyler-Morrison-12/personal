fetch('data.json')
.then(response => response.json())
.then(data => {
    const imageDataC = data.icon[0];

    const gameImageC = document.getElementById('pongImageC');

    gameImageC.src = imageDataC.src;
    gameImageC.alt = imageDataC.alt;
})
.catch(error => console.error('Error fetching the JSON:', error));

const homeButton = document.getElementById("home-Button");
const settingButton = document.getElementById("settings-Button");
const contactButton = document.getElementById("contact-Button");
const accountButton = document.getElementById("account-Button");

homeButton.addEventListener("click", function(){
    window.location = "./index.html";
});
settingButton.addEventListener("click", function(){
    window.location = "./settings.html";
});
contactButton.addEventListener("click", function(){
    window.location = "./contact.html";
});
accountButton.addEventListener("click", function(){
    window.location = "./account.html";
});

