fetch('data.json')
.then(response => response.json())
.then(data => {
    const imageDataA = data.images[0];
    const imageDataB = data.images[1];
    const imageDataC = data.icon[0];

    const gameImageA = document.getElementById('pongImageA');
    const gameImageB = document.getElementById('pongImageB');
    const gameImageC = document.getElementById('pongImageC');

    const pongText = document.getElementById('pongGameText');
    const comingSoonText = document.getElementById('comingSoonText');

    gameImageA.src = imageDataA.src;
    gameImageA.alt = imageDataA.alt;
    pongText.innerHTML = imageDataA.text;

    gameImageB.src = imageDataB.src;
    gameImageB.alt = imageDataB.alt;
    comingSoonText.innerHTML = imageDataB.text;
    
    gameImageC.src = imageDataC.src;
    gameImageC.alt = imageDataC.alt;
})
.catch(error => console.error('Error fetching the JSON:', error));

const homeButton = document.getElementById("home-Button");
const settingButton = document.getElementById("settings-Button");
const contactButton = document.getElementById("contact-Button");
const accountButton = document.getElementById("account-Button");
const pongButton = document.getElementById("pongGameButton");

homeButton.addEventListener("click", function(){
    window.location = "./index.html";
});
settingButton.addEventListener("click", function(){
    window.location = "./settings.html";
});
contactButton.addEventListener("click", function(){
    window.location = "./contact.html";
});
accountButton.addEventListener("click", function(){
    window.location = "./account.html";
});
pongButton.addEventListener("click", function(){
    window.location = "./game.html";
});
