fetch('data.json')
.then(response => response.json())
.then(data => {
    const imageDataC = data.icon[0];

    const gameImageC = document.getElementById('pongImageC');

    gameImageC.src = imageDataC.src;
    gameImageC.alt = imageDataC.alt;

    const themeImageA = data.themeImages[0];
    const themeImageB = data.themeImages[1];
    const themeImageC = data.themeImages[2];
    const themeImageD = data.themeImages[3];
    const themeImageE = data.themeImages[4];
    const themeImageF = data.themeImages[5];
    const themeImageG = data.themeImages[6];
    const themeImageH = data.themeImages[7];

    const defaultTheme = document.getElementById('defaultTheme');
    const blackTheme = document.getElementById('blackTheme');
    const redTheme = document.getElementById('redTheme');
    const orangeTheme = document.getElementById('orangeTheme');
    const yellowTheme = document.getElementById('yellowTheme');
    const greenTheme = document.getElementById('greenTheme');
    const purpleTheme = document.getElementById('purpleTheme');
    const blueTheme = document.getElementById('blueTheme');

    defaultTheme.src = themeImageA.src;
    defaultTheme.alt = themeImageA.alt;
    blackTheme.src = themeImageB.src;
    blackTheme.alt = themeImageB.alt;
    redTheme.src = themeImageC.src;
    redTheme.alt = themeImageC.alt;
    orangeTheme.src = themeImageD.src;
    orangeTheme.alt = themeImageD.alt;
    yellowTheme.src = themeImageE.src;
    yellowTheme.alt = themeImageE.alt;
    greenTheme.src = themeImageF.src;
    greenTheme.alt = themeImageF.alt;
    purpleTheme.src = themeImageG.src;
    purpleTheme.alt = themeImageG.alt;
    blueTheme.src = themeImageH.src;
    blueTheme.alt = themeImageH.alt;

})
.catch(error => console.error('Error fetching the JSON:', error));

const homeButton = document.getElementById("home-Button");
const settingButton = document.getElementById("settings-Button");
const contactButton = document.getElementById("contact-Button");
const accountButton = document.getElementById("account-Button");
const defaultThemeButton = document.getElementById("defaultButtonTheme")
const blackThemeButton = document.getElementById("blackButtonTheme")
const redThemeButton = document.getElementById("redButtonTheme")
const orangeThemeButton = document.getElementById("orangeButtonTheme")
const yellowThemeButton = document.getElementById("yellowButtonTheme")
const greenThemeButton = document.getElementById("greenButtonTheme")
const purpleThemeButton = document.getElementById("purpleButtonTheme")
const blueThemeButton = document.getElementById("blueButtonTheme")
const headerTheme = document.getElementById("myHeader");
const containerTheme = document.getElementById("myContainer");
const rightTheme = document.getElementById("rightSide");
const leftTheme = document.getElementById("leftSide");
const footerTheme = document.getElementById("myFooter");

homeButton.addEventListener("click", function(){
    window.location = "./index.html";
});
settingButton.addEventListener("click", function(){
    window.location = "./settings.html";
});
contactButton.addEventListener("click", function(){
    window.location = "./contact.html";
});
accountButton.addEventListener("click", function(){
    window.location = "./account.html";
});

defaultThemeButton.addEventListener("click", function(){
    headerTheme.style.backgroundColor = "rgb(230, 230, 230)";
    rightTheme.style.backgroundColor = "rgb(230, 230, 230)";
    leftTheme.style.backgroundColor = "rgb(230, 230, 230)";
    containerTheme.style.backgroundColor = "rgb(230, 230, 230)";
    footerTheme.style.backgroundColor = "rgb(230, 230, 230)";

    document.body.style.color = "black";
    homeButton.style.backgroundColor = "white";
    settingButton.style.backgroundColor = "black";
    contactButton.style.backgroundColor = "white";
    accountButton.style.backgroundColor = "whtie";
})
blackThemeButton.addEventListener("click", function(){
    headerTheme.style.backgroundColor = "black";
    rightTheme.style.backgroundColor = "black";
    leftTheme.style.backgroundColor = "black";
    containerTheme.style.backgroundColor = "black";
    footerTheme.style.backgroundColor = "black";

    document.body.style.color = "white";
    homeButton.style.backgroundColor = "darkgray";
    settingButton.style.backgroundColor = "rgb(50, 50, 50)";
    contactButton.style.backgroundColor = "darkgray";
    accountButton.style.backgroundColor = "darkgray";
})
redThemeButton.addEventListener("click", function(){
    headerTheme.style.backgroundColor = "red";
    rightTheme.style.backgroundColor = "red";
    leftTheme.style.backgroundColor = "red";
    containerTheme.style.backgroundColor = "red";
    footerTheme.style.backgroundColor = "red";

    document.body.style.color = "white";
    homeButton.style.backgroundColor = "white";
    settingButton.style.backgroundColor = "rgb(150, 5, 5)";
    contactButton.style.backgroundColor = "white";
    accountButton.style.backgroundColor = "white";
})
orangeThemeButton.addEventListener("click", function(){

    headerTheme.style.backgroundColor = "orange";
    rightTheme.style.backgroundColor = "orange";
    leftTheme.style.backgroundColor = "orange";
    containerTheme.style.backgroundColor = "orange";
    footerTheme.style.backgroundColor = "orange";

    document.body.style.color = "black";
    homeButton.style.backgroundColor = "white";
    settingButton.style.backgroundColor = "rgb(250, 100, 5)";
    contactButton.style.backgroundColor = "white";
    accountButton.style.backgroundColor = "white";
})
yellowThemeButton.addEventListener("click", function(){
    headerTheme.style.backgroundColor = "yellow";
    rightTheme.style.backgroundColor = "yellow";
    leftTheme.style.backgroundColor = "yellow";
    containerTheme.style.backgroundColor = "yellow";
    footerTheme.style.backgroundColor = "yellow";

    document.body.style.color = "black";
    homeButton.style.backgroundColor = "white";
    settingButton.style.backgroundColor = "rgb(171, 158, 25)";
    contactButton.style.backgroundColor = "white";
    accountButton.style.backgroundColor = "whtie";
})
greenThemeButton.addEventListener("click", function(){
    headerTheme.style.backgroundColor = "green";
    rightTheme.style.backgroundColor = "green";
    leftTheme.style.backgroundColor = "green";
    containerTheme.style.backgroundColor = "green";
    footerTheme.style.backgroundColor = "green";

    document.body.style.color = "white";
    homeButton.style.backgroundColor = "white";
    settingButton.style.backgroundColor = "rgb(0, 80, 40)";
    contactButton.style.backgroundColor = "white";
    accountButton.style.backgroundColor = "whtie";
})
purpleThemeButton.addEventListener("click", function(){
    headerTheme.style.backgroundColor = "purple";
    rightTheme.style.backgroundColor = "purple";
    leftTheme.style.backgroundColor = "purple";
    containerTheme.style.backgroundColor = "purple";
    footerTheme.style.backgroundColor = "purple";

    document.body.style.color = "white";
    homeButton.style.backgroundColor = "white";
    settingButton.style.backgroundColor = "rgb(50, 0, 80)";
    contactButton.style.backgroundColor = "white";
    accountButton.style.backgroundColor = "whtie";
})
blueThemeButton.addEventListener("click", function(){
    headerTheme.style.backgroundColor = "blue";
    rightTheme.style.backgroundColor = "blue";
    leftTheme.style.backgroundColor = "blue";
    containerTheme.style.backgroundColor = "blue";
    footerTheme.style.backgroundColor = "blue";

    document.body.style.color = "white";
    homeButton.style.backgroundColor = "white";
    settingButton.style.backgroundColor = "rgb(10, 26, 98)";
    contactButton.style.backgroundColor = "white";
    accountButton.style.backgroundColor = "whtie";
})
